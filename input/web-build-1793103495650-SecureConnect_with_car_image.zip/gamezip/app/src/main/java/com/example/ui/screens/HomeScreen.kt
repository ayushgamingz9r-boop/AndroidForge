package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NoAccounts
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CallType
import com.example.model.Contact
import com.example.model.MediaType
import com.example.ui.CipherViewModel
import com.example.ui.HubTab
import com.example.ui.components.AvatarBadge
import com.example.ui.components.CyberCard
import com.example.ui.components.EncryptedBadge
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberError
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberSecondary
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberSurfaceVariant
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(viewModel: CipherViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()
    val identity by viewModel.identity.collectAsState()
    var showAddContactDialog by remember { mutableStateOf(false) }
    var showCreateGroupDialog by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBackground),
        topBar = {
            TopHeaderBar(
                username = identity.username,
                tag = identity.tag,
                avatarId = identity.avatarId,
                masterPasscode = identity.masterPassword,
                onPanicLock = { viewModel.lockApp() }
            )
        },
        bottomBar = {
            CyberBottomNav(
                currentTab = currentTab,
                onSelectTab = { viewModel.setTab(it) }
            )
        },
        floatingActionButton = {
            if (currentTab == HubTab.CHATS) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FloatingActionButton(
                        onClick = { showCreateGroupDialog = true },
                        containerColor = CyberSecondary,
                        contentColor = CyberBackground,
                        shape = CircleShape,
                        modifier = Modifier.testTag("create_group_fab")
                    ) {
                        Icon(imageVector = Icons.Default.GroupAdd, contentDescription = "Create Group")
                    }

                    FloatingActionButton(
                        onClick = { showAddContactDialog = true },
                        containerColor = CyberPrimary,
                        contentColor = CyberBackground,
                        shape = CircleShape,
                        modifier = Modifier.testTag("add_contact_fab")
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Add Contact")
                    }
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = CyberBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                HubTab.CHATS -> ChatsTabContent(viewModel, onOpenCreateGroup = { showCreateGroupDialog = true })
                HubTab.CALLS -> CallsTabContent(viewModel)
                HubTab.VAULT_IDENTITY -> VaultIdentityTabContent(viewModel, snackbarHostState)
                HubTab.CIPHER_AUDIT -> CipherAuditTabContent(viewModel)
            }
        }
    }

    if (showAddContactDialog) {
        AddContactDialog(
            onDismiss = { showAddContactDialog = false },
            onAdd = { name, tag ->
                viewModel.addContact(name, tag)
                showAddContactDialog = false
            }
        )
    }

    if (showCreateGroupDialog) {
        CreateGroupDialog(
            contacts = viewModel.contacts.collectAsState().value.filter { !it.isGroup },
            onDismiss = { showCreateGroupDialog = false },
            onCreate = { groupName, members, avatarId ->
                viewModel.createGroup(groupName, members, avatarId)
                showCreateGroupDialog = false
            }
        )
    }
}

@Composable
private fun TopHeaderBar(
    username: String,
    tag: String,
    avatarId: String,
    masterPasscode: String,
    onPanicLock: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(CyberSurface)
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Column {
            // "Made by Aayush" Branded Top Ribbon
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Created by Aayush",
                        tint = CyberPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "Developed By Ayush",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "• Private Enclave",
                        fontSize = 11.sp,
                        color = CyberPrimary,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = CyberSurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberOutline)
                ) {
                    Text(
                        text = "KEY: $masterPasscode",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberSecondary,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            // User Identity & Panic Lock
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AvatarBadge(avatarId = avatarId, size = 42.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = username,
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(CyberPrimary)
                            )
                        }
                        Text(
                            text = tag,
                            color = CyberPrimary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    EncryptedBadge(text = "ZERO GALLERY SAVE")
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = onPanicLock,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(CyberError.copy(alpha = 0.15f))
                            .border(1.dp, CyberError.copy(alpha = 0.5f), CircleShape)
                            .testTag("panic_lock_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PowerSettingsNew,
                            contentDescription = "Panic Lock",
                            tint = CyberError,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CyberBottomNav(
    currentTab: HubTab,
    onSelectTab: (HubTab) -> Unit
) {
    NavigationBar(
        containerColor = CyberSurface,
        contentColor = Color.White,
        modifier = Modifier.navigationBarsPadding()
    ) {
        NavigationBarItem(
            selected = currentTab == HubTab.CHATS,
            onClick = { onSelectTab(HubTab.CHATS) },
            icon = { Icon(Icons.Default.Chat, contentDescription = "Chats") },
            label = { Text("Chats", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CyberBackground,
                selectedTextColor = CyberPrimary,
                indicatorColor = CyberPrimary,
                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
            )
        )

        NavigationBarItem(
            selected = currentTab == HubTab.CALLS,
            onClick = { onSelectTab(HubTab.CALLS) },
            icon = { Icon(Icons.Default.Call, contentDescription = "Calls") },
            label = { Text("Calls", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CyberBackground,
                selectedTextColor = CyberPrimary,
                indicatorColor = CyberPrimary,
                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
            )
        )

        NavigationBarItem(
            selected = currentTab == HubTab.VAULT_IDENTITY,
            onClick = { onSelectTab(HubTab.VAULT_IDENTITY) },
            icon = { Icon(Icons.Default.Person, contentDescription = "Settings") },
            label = { Text("Settings", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CyberBackground,
                selectedTextColor = CyberPrimary,
                indicatorColor = CyberPrimary,
                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
            )
        )

        NavigationBarItem(
            selected = currentTab == HubTab.CIPHER_AUDIT,
            onClick = { onSelectTab(HubTab.CIPHER_AUDIT) },
            icon = { Icon(Icons.Default.Security, contentDescription = "Audit") },
            label = { Text("Audit", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CyberBackground,
                selectedTextColor = CyberPrimary,
                indicatorColor = CyberPrimary,
                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
            )
        )
    }
}

// ----------------- TAB 1: CHATS -----------------
@Composable
private fun ChatsTabContent(
    viewModel: CipherViewModel,
    onOpenCreateGroup: () -> Unit
) {
    val contacts by viewModel.contacts.collectAsState()
    val messagesMap by viewModel.messages.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, DIRECT, GROUPS

    val filteredContacts = contacts.filter { contact ->
        val matchesSearch = contact.name.contains(searchQuery, ignoreCase = true) || contact.tag.contains(searchQuery, ignoreCase = true)
        val matchesCategory = when (selectedFilter) {
            "DIRECT" -> !contact.isGroup
            "GROUPS" -> contact.isGroup
            else -> true
        }
        matchesSearch && matchesCategory
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Search bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search encrypted chats, groups or @tags...") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                },
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberPrimary,
                    unfocusedBorderColor = CyberOutline,
                    unfocusedContainerColor = CyberSurface,
                    focusedContainerColor = CyberSurface
                ),
                singleLine = true
            )
        }

        // Category Filter Chips & Create Group shortcut
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip("ALL", selectedFilter == "ALL") { selectedFilter = "ALL" }
                    FilterChip("DIRECT", selectedFilter == "DIRECT") { selectedFilter = "DIRECT" }
                    FilterChip("GROUPS", selectedFilter == "GROUPS") { selectedFilter = "GROUPS" }
                }

                TextButton(onClick = onOpenCreateGroup) {
                    Icon(Icons.Default.GroupAdd, contentDescription = null, tint = CyberSecondary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("New Group", color = CyberSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // List Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "ACTIVE CHANNELS (${filteredContacts.size})",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberPrimary,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Encrypted in Memory Only",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        items(filteredContacts, key = { it.id }) { contact ->
            val chatMessages = messagesMap[contact.id] ?: emptyList()
            val lastMessage = chatMessages.lastOrNull()

            CyberCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("contact_item_${contact.id}"),
                onClick = { viewModel.openChat(contact) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AvatarBadge(
                        avatarId = contact.avatarId,
                        size = 50.dp,
                        showOnlineStatus = !contact.isGroup,
                        isOnline = contact.isOnline
                    )

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = contact.name,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (contact.isGroup) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = CyberSecondary.copy(alpha = 0.2f),
                                        border = androidx.compose.foundation.BorderStroke(0.5.dp, CyberSecondary)
                                    ) {
                                        Text(
                                            text = "GROUP",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = CyberSecondary,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            }

                            Text(
                                text = lastMessage?.timeFormatted ?: "Active",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Text(
                            text = if (contact.isGroup) "${contact.groupMembers.size} members • ${contact.tag}" else contact.tag,
                            fontSize = 11.sp,
                            color = if (contact.isGroup) CyberSecondary else CyberPrimary,
                            fontFamily = FontFamily.Monospace
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = lastMessage?.text ?: "No messages yet. Direct encryption active.",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )

                            if (contact.disappearingDurationSeconds > 0) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = Icons.Default.Timer,
                                    contentDescription = "Timer",
                                    tint = CyberSecondary,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FilterChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (selected) CyberPrimary else CyberSurfaceVariant,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) CyberPrimary else CyberOutline),
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (selected) CyberBackground else Color.White,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
    }
}

// ----------------- TAB 2: CALLS -----------------
@Composable
private fun CallsTabContent(viewModel: CipherViewModel) {
    val callLogs by viewModel.callLogs.collectAsState()
    val contacts by viewModel.contacts.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Incoming Call Test Banner
        item {
            CyberCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = CyberSecondary.copy(alpha = 0.5f)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = "Simulate",
                            tint = CyberSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Test Real Incoming Call HUD",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberSecondary
                        )
                    }

                    Text(
                        text = "Real-time incoming call alert interface test karein (Voice ya Video):",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.simulateIncomingCall(CallType.VIDEO) },
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .testTag("test_incoming_video_btn"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyberPrimary,
                                contentColor = CyberBackground
                            )
                        ) {
                            Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Incoming Video", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { viewModel.simulateIncomingCall(CallType.VOICE) },
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .testTag("test_incoming_voice_btn"),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CyberPrimary)
                        ) {
                            Icon(Icons.Default.Call, contentDescription = null, tint = CyberPrimary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Incoming Voice", fontSize = 11.sp, color = CyberPrimary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Quick Direct Secure Dial
        item {
            Text(
                text = "DIRECT ENCRYPTED DIAL",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = CyberPrimary,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(vertical = 4.dp)
            )

            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(contacts.filter { !it.isGroup }) { contact ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = CyberSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyberOutline),
                        modifier = Modifier
                            .width(130.dp)
                            .clickable { viewModel.startVoiceCall(contact) }
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            AvatarBadge(avatarId = contact.avatarId, size = 42.dp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = contact.name,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(CyberPrimary)
                                        .clickable { viewModel.startVoiceCall(contact) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Call,
                                        contentDescription = "Voice Call",
                                        tint = CyberBackground,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(CyberSecondary)
                                        .clickable { viewModel.startVideoCall(contact) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Videocam,
                                        contentDescription = "Video Call",
                                        tint = CyberBackground,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "CALL LOGS (E2EE SRTP)",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = CyberPrimary,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        if (callLogs.isEmpty()) {
            item {
                Text(
                    text = "No call logs yet. Initiate encrypted voice or video calls above.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }
        } else {
            items(callLogs) { log ->
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AvatarBadge(avatarId = log.contact.avatarId, size = 42.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = log.contact.name,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (log.wasIncoming) Icons.Default.CallReceived else Icons.Default.CallMade,
                                    contentDescription = null,
                                    tint = if (log.wasMissed) CyberError else CyberPrimary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (log.callType == CallType.VIDEO) "Video • ${log.durationFormatted}" else "Voice • ${log.durationFormatted}",
                                    fontSize = 12.sp,
                                    color = if (log.wasMissed) CyberError else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        IconButton(onClick = {
                            if (log.callType == CallType.VIDEO) viewModel.startVideoCall(log.contact)
                            else viewModel.startVoiceCall(log.contact)
                        }) {
                            Icon(
                                imageVector = if (log.callType == CallType.VIDEO) Icons.Default.Videocam else Icons.Default.Call,
                                contentDescription = "Call Back",
                                tint = CyberPrimary
                            )
                        }
                    }
                }
            }
        }
    }
}

// ----------------- TAB 3: SETTINGS & VAULT -----------------
@Composable
private fun VaultIdentityTabContent(
    viewModel: CipherViewModel,
    snackbarHostState: SnackbarHostState
) {
    val identity by viewModel.identity.collectAsState()
    var editUsername by remember { mutableStateOf(identity.username) }
    var editStatus by remember { mutableStateOf(identity.status) }
    var selectedAvatar by remember { mutableStateOf(identity.avatarId) }
    var showPasswordDialog by remember { mutableStateOf(false) }
    var showDeleteAllConfirm by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Identity Hero Banner
        CyberCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = CyberPrimary.copy(alpha = 0.5f)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                AvatarBadge(avatarId = selectedAvatar, size = 70.dp)
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = identity.username,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = identity.tag,
                    fontSize = 13.sp,
                    color = CyberPrimary,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = CyberSurfaceElevated
                ) {
                    Text(
                        text = "Developed By Ayush • Enclave Active",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = CyberSecondary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
        }

        // 1-CLICK DELETE ALL CHATS FEATURE (Requested specifically by user)
        CyberCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = CyberError.copy(alpha = 0.6f)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.DeleteForever,
                        contentDescription = "Delete All Chats",
                        tint = CyberError,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "1-CLICK DELETE ALL CHATS",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberError,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Ek hi click mein aapke sabhi direct aur group chats ke messages permanent delete ho jayenge:",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { showDeleteAllConfirm = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("delete_all_chats_btn"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberError,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("DELETE ALL CHATS IN 1-CLICK", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        // ZERO GALLERY SAVE GUARANTEE CARD
        CyberCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = CyberPrimary.copy(alpha = 0.4f)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Gallery Protected",
                        tint = CyberPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ZERO GALLERY SAVE (ANTI-LEAK)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberPrimary,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Aapke bheje ya receive kiye gaye koi bhi photo ya video phone ki gallery (DCIM / MediaStore) mein save nahi honge. Vah sirf is encrypted app ke memory sandbox mein hi safe rahenge.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CyberPrimary, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Sandboxed App Storage Only • Android Gallery Blocked", fontSize = 11.sp, color = CyberPrimary)
                }
            }
        }

        // Edit Profile & Avatar
        CyberCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "PROFILE & AVATAR SETTINGS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberPrimary,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("Choose Profile Avatar Preset", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(6.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(viewModel.repository.avatarPresets) { preset ->
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(if (selectedAvatar == preset.id) CyberPrimary.copy(alpha = 0.3f) else CyberSurfaceVariant)
                                .border(
                                    width = if (selectedAvatar == preset.id) 2.dp else 1.dp,
                                    color = if (selectedAvatar == preset.id) CyberPrimary else CyberOutline,
                                    shape = CircleShape
                                )
                                .clickable { selectedAvatar = preset.id },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = preset.emoji, fontSize = 22.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = editUsername,
                    onValueChange = { editUsername = it },
                    label = { Text("Display Username") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberPrimary,
                        unfocusedBorderColor = CyberOutline
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = editStatus,
                    onValueChange = { editStatus = it },
                    label = { Text("Profile Status Tagline") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberPrimary,
                        unfocusedBorderColor = CyberOutline
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        viewModel.updateProfile(editUsername, editStatus, selectedAvatar, null)
                        scope.launch {
                            snackbarHostState.showSnackbar("Profile & Avatar updated successfully!")
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberPrimary,
                        contentColor = CyberBackground
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("SAVE PROFILE CHANGES", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        // Security Enclave & Passcode Settings
        CyberCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "ACCESS PASSCODE & BIOMETRICS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberPrimary,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Master App Passcode", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                        Text("Active: ${identity.masterPassword}", fontSize = 12.sp, color = CyberSecondary, fontFamily = FontFamily.Monospace)
                    }
                    OutlinedButton(
                        onClick = { showPasswordDialog = true },
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyberSecondary)
                    ) {
                        Text("Change Key", color = CyberSecondary, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Face Verification On Launch",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                        Text(
                            text = if (identity.requireFaceUnlock) "Status: ON (App kholte hi camera face scan mangega)" else "Status: OFF (Setting me tick karenge tabhi face scan mangega)",
                            fontSize = 12.sp,
                            color = if (identity.requireFaceUnlock) CyberPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = identity.requireFaceUnlock,
                        onCheckedChange = { viewModel.setRequireFaceUnlock(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = CyberBackground,
                            checkedTrackColor = CyberPrimary
                        )
                    )
                }

                if (identity.requireFaceUnlock) {
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { viewModel.openFaceScanTest() },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyberPrimary)
                    ) {
                        Icon(Icons.Default.Face, contentDescription = null, tint = CyberPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Test / Calibrate Face Scan", color = CyberPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showDeleteAllConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteAllConfirm = false },
            title = { Text("Confirm 1-Click Chat Deletion", color = CyberError) },
            text = { Text("Kya aap sach me sabhi chats aur encrypted messages ko ek click mein delete karna chahte hain?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteAllChats()
                        showDeleteAllConfirm = false
                        scope.launch {
                            snackbarHostState.showSnackbar("Sabhi chats delete ho gayi!")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberError)
                ) {
                    Text("YES, DELETE ALL")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAllConfirm = false }) {
                    Text("Cancel", color = Color.White)
                }
            },
            containerColor = CyberSurface
        )
    }

    if (showPasswordDialog) {
        ChangePasswordDialog(
            currentPassword = identity.masterPassword,
            onDismiss = { showPasswordDialog = false },
            onSave = { newPass ->
                viewModel.updateMasterPassword(newPass)
                showPasswordDialog = false
                scope.launch {
                    snackbarHostState.showSnackbar("Master passcode updated to: $newPass")
                }
            }
        )
    }
}

// ----------------- TAB 4: CIPHER AUDIT -----------------
@Composable
private fun CipherAuditTabContent(viewModel: CipherViewModel) {
    val identity by viewModel.identity.collectAsState()
    var showZeroizeConfirm by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        CyberCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = CyberPrimary
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "Shield",
                        tint = CyberPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "MILITARY CIPHER ENGINE",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberPrimary,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                AuditMetricRow("Encryption Standard", "AES-256-GCM Authenticated")
                AuditMetricRow("Key Exchange Protocol", "X25519 Double Ratchet")
                AuditMetricRow("Voice/Video Transport", "DTLS 1.3 / SRTP Encrypted")
                AuditMetricRow("Media Gallery Export", "DISABLED (Sandboxed Memory)")
                AuditMetricRow("Author Branding", "Developed By Ayush")
                AuditMetricRow("SIM / Phone Metadata", "0 Bytes (Zero Telemetry)")
                AuditMetricRow("Real-Time Cloud Relay", "Firebase Firestore (E2EE Active)")
            }
        }

        CyberCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "CRYPTOGRAPHIC FINGERPRINT",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberSecondary,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = identity.fingerprint,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberPrimary,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Public Key: ${identity.publicKey}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Emergency Zeroize Wipe
        CyberCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = CyberError.copy(alpha = 0.6f)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "Wipe",
                        tint = CyberError,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "EMERGENCY ZEROIZE PROTOCOL",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberError,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Wipes all conversations, resets cryptographic keypairs, and locks the enclave immediately.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = { showZeroizeConfirm = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("zeroize_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberError,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("TRIGGER ZEROIZE PROTOCOL", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }

    if (showZeroizeConfirm) {
        AlertDialog(
            onDismissRequest = { showZeroizeConfirm = false },
            title = { Text("Confirm Zeroize Protocol", color = CyberError) },
            text = { Text("All local conversation history, media, and encryption cache will be permanently zeroized. Continue?") },
            confirmButton = {
                Button(
                    onClick = {
                        showZeroizeConfirm = false
                        viewModel.zeroizeAllData()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberError)
                ) {
                    Text("ZEROIZE DATA")
                }
            },
            dismissButton = {
                TextButton(onClick = { showZeroizeConfirm = false }) {
                    Text("Cancel", color = Color.White)
                }
            },
            containerColor = CyberSurface
        )
    }
}

@Composable
private fun AuditMetricRow(title: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = title, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = CyberPrimary)
    }
}

// Dialogs
@Composable
private fun AddContactDialog(
    onDismiss: () -> Unit,
    onAdd: (name: String, tag: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var tag by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Encrypted Peer", color = Color.White) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Peer ka unique anonymous tag enter karein (no phone number required):",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Peer Display Name") },
                    placeholder = { Text("e.g. Alex Cipher") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CyberPrimary)
                )
                OutlinedTextField(
                    value = tag,
                    onValueChange = { tag = it },
                    label = { Text("Unique Tag (@username#1234)") },
                    placeholder = { Text("e.g. @alex_cipher#8812") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CyberPrimary)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { if (name.isNotBlank()) onAdd(name, tag) },
                colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberBackground)
            ) {
                Text("ADD PEER", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color.White)
            }
        },
        containerColor = CyberSurface
    )
}

@Composable
private fun CreateGroupDialog(
    contacts: List<Contact>,
    onDismiss: () -> Unit,
    onCreate: (groupName: String, members: List<String>, avatarId: String) -> Unit
) {
    var groupName by remember { mutableStateOf("") }
    val selectedMembers = remember { mutableStateOf(mutableSetOf<String>()) }
    var selectedAvatar by remember { mutableStateOf("enclave_shield") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.GroupAdd, contentDescription = null, tint = CyberPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Create Encrypted Group", color = Color.White, fontSize = 16.sp)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Naya encrypted group banayein. Group me share kiye photos aur videos gallery me save nahi honge.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = groupName,
                    onValueChange = { groupName = it },
                    label = { Text("Group Name") },
                    placeholder = { Text("e.g. Alpha Tactical Team") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CyberPrimary)
                )

                Text("Select Members to Add:", fontSize = 12.sp, color = CyberPrimary, fontWeight = FontWeight.SemiBold)

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    contacts.forEach { contact ->
                        val isChecked = selectedMembers.value.contains(contact.name)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isChecked) CyberPrimary.copy(alpha = 0.15f) else CyberSurfaceVariant)
                                .clickable {
                                    val newSet = selectedMembers.value.toMutableSet()
                                    if (isChecked) newSet.remove(contact.name) else newSet.add(contact.name)
                                    selectedMembers.value = newSet
                                }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AvatarBadge(avatarId = contact.avatarId, size = 28.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = contact.name,
                                color = if (isChecked) CyberPrimary else Color.White,
                                fontSize = 13.sp,
                                modifier = Modifier.weight(1f)
                            )
                            if (isChecked) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CyberPrimary, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (groupName.isNotBlank()) {
                        onCreate(groupName, selectedMembers.value.toList(), selectedAvatar)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberBackground)
            ) {
                Text("CREATE GROUP", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color.White)
            }
        },
        containerColor = CyberSurface
    )
}

@Composable
private fun ChangePasswordDialog(
    currentPassword: String,
    onDismiss: () -> Unit,
    onSave: (newPassword: String) -> Unit
) {
    var newPassword by remember { mutableStateOf(currentPassword) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Change Enclave Passcode", color = Color.White) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Naya access password dalein. Sirf is password se login karne wale ko hi chats dikhai dengi:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(
                    value = newPassword,
                    onValueChange = { newPassword = it },
                    label = { Text("New Passcode") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CyberPrimary)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { if (newPassword.isNotBlank()) onSave(newPassword.trim()) },
                colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberBackground)
            ) {
                Text("UPDATE KEY", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color.White)
            }
        },
        containerColor = CyberSurface
    )
}
