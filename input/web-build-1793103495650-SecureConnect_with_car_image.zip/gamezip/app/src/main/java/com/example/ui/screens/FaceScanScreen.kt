package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.CipherViewModel
import com.example.ui.FaceScanStatus
import com.example.ui.components.CameraPreview
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberSecondary
import com.example.ui.theme.CyberSurface

@Composable
fun FaceScanScreen(viewModel: CipherViewModel) {
    val scanStatus by viewModel.faceScanStatus.collectAsState()
    val scanProgress by viewModel.faceScanProgress.collectAsState()

    val infiniteTransition = rememberInfiniteTransition(label = "laserScan")
    val laserY by infiniteTransition.animateFloat(
        initialValue = 0.1f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Real front CameraX preview with dark overlay
        CameraPreview(
            isFrontCamera = true,
            modifier = Modifier.fillMaxSize(),
            onPermissionGranted = {
                if (scanStatus == FaceScanStatus.IDLE) {
                    viewModel.startFaceScan()
                }
            }
        )

        // Semi-transparent privacy vignette
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color.Transparent,
                            CyberBackground.copy(alpha = 0.6f),
                            CyberBackground.copy(alpha = 0.92f)
                        ),
                        radius = 900f
                    )
                )
        )

        // Biometric Face Reticle & Scanning HUD
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = CyberBackground.copy(alpha = 0.85f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberPrimary)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "Face Security",
                            tint = CyberPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Developed By Ayush • Biometric Enclave",
                            color = CyberPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Look directly at the camera",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Text(
                    text = "Verifying live biometric neural hash",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp
                )
            }

            // Central Oval Reticle with laser sweep
            Box(
                modifier = Modifier
                    .size(width = 240.dp, height = 310.dp)
                    .clip(RoundedCornerShape(120.dp))
                    .border(2.dp, CyberPrimary.copy(alpha = 0.6f), RoundedCornerShape(120.dp)),
                contentAlignment = Alignment.Center
            ) {
                // Canvas Laser Scan line & targeting brackets
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val scanLineY = size.height * laserY

                    // Laser sweep line
                    drawLine(
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                Color.Transparent,
                                CyberSecondary,
                                CyberPrimary,
                                CyberSecondary,
                                Color.Transparent
                            )
                        ),
                        start = Offset(0f, scanLineY),
                        end = Offset(size.width, scanLineY),
                        strokeWidth = 4.dp.toPx()
                    )

                    // Reticle corner ticks
                    val tickLen = 24.dp.toPx()
                    val strokeW = 3.dp.toPx()

                    // Top Left
                    drawLine(CyberPrimary, Offset(20f, 40f), Offset(20f + tickLen, 40f), strokeW)
                    drawLine(CyberPrimary, Offset(20f, 40f), Offset(20f, 40f + tickLen), strokeW)

                    // Top Right
                    drawLine(CyberPrimary, Offset(size.width - 20f, 40f), Offset(size.width - 20f - tickLen, 40f), strokeW)
                    drawLine(CyberPrimary, Offset(size.width - 20f, 40f), Offset(size.width - 20f, 40f + tickLen), strokeW)

                    // Bottom Left
                    drawLine(CyberPrimary, Offset(20f, size.height - 40f), Offset(20f + tickLen, size.height - 40f), strokeW)
                    drawLine(CyberPrimary, Offset(20f, size.height - 40f), Offset(20f, size.height - 40f - tickLen), strokeW)

                    // Bottom Right
                    drawLine(CyberPrimary, Offset(size.width - 20f, size.height - 40f), Offset(size.width - 20f - tickLen, size.height - 40f), strokeW)
                    drawLine(CyberPrimary, Offset(size.width - 20f, size.height - 40f), Offset(size.width - 20f, size.height - 40f - tickLen), strokeW)
                }

                // Center Icon / Status
                when (scanStatus) {
                    FaceScanStatus.VERIFIED -> {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(CyberPrimary)
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Verified",
                                tint = CyberBackground,
                                modifier = Modifier.size(48.dp)
                            )
                        }
                    }
                    else -> {
                        Icon(
                            imageVector = Icons.Default.Face,
                            contentDescription = "Face Align",
                            tint = CyberPrimary.copy(alpha = 0.35f),
                            modifier = Modifier.size(110.dp)
                        )
                    }
                }
            }

            // Bottom Scanning Telemetry & Controls
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = CyberSurface.copy(alpha = 0.94f),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberPrimary.copy(alpha = 0.3f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val statusText = when (scanStatus) {
                        FaceScanStatus.SCANNING -> "Analyzing Facial Landmarks..."
                        FaceScanStatus.ALIGNED -> "Face Aligned: Verifying Zero-Knowledge Proof..."
                        FaceScanStatus.VERIFIED -> "BIOMETRIC MATCH CONFIRMED (99.8%)"
                        FaceScanStatus.FAILED -> "Face Not Recognized. Retrying..."
                        FaceScanStatus.IDLE -> "Face Verification Ready"
                    }

                    Text(
                        text = statusText,
                        color = if (scanStatus == FaceScanStatus.VERIFIED) CyberPrimary else Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    LinearProgressIndicator(
                        progress = { scanProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = CyberPrimary,
                        trackColor = CyberBackground
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { viewModel.startFaceScan() },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("face_scan_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyberPrimary,
                                contentColor = CyberBackground
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Scan Again",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "SCAN FACE",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }

                        OutlinedButton(
                            onClick = { viewModel.skipOrBypassFaceScan() },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("bypass_face_button"),
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CyberSecondary)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LockOpen,
                                contentDescription = "Bypass",
                                tint = CyberSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "VERIFY NOW",
                                color = CyberSecondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
