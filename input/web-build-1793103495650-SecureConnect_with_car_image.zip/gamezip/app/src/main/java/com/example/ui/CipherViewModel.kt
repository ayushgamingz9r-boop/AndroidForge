package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CipherRepository
import com.example.model.CallState
import com.example.model.CallType
import com.example.model.Contact
import com.example.model.MediaType
import com.example.model.Message
import com.example.model.UserIdentity
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ScreenState {
    UNLOCK_PASSCODE,
    UNLOCK_FACE,
    MAIN_HUB,
    CHAT,
    VOICE_CALL,
    VIDEO_CALL
}

enum class HubTab {
    CHATS,
    CALLS,
    VAULT_IDENTITY,
    CIPHER_AUDIT
}

enum class FaceScanStatus {
    IDLE,
    SCANNING,
    ALIGNED,
    VERIFIED,
    FAILED
}

class CipherViewModel(
    application: Application
) : AndroidViewModel(application) {
    val repository: CipherRepository = CipherRepository(application)

    val identity: StateFlow<UserIdentity> = repository.identity
        .stateIn(viewModelScope, SharingStarted.Eagerly, UserIdentity())

    val contacts: StateFlow<List<Contact>> = repository.contacts
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val messages: StateFlow<Map<String, List<Message>>> = repository.messages
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    val activeCall: StateFlow<CallState?> = repository.activeCall
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val incomingCall: StateFlow<CallState?> = repository.incomingCall
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val callLogs = repository.callLogs
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val isPasscodeUnlocked = repository.isPasscodeUnlocked
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val isFaceScanVerified = repository.isFaceScanVerified
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    private val _currentScreen = MutableStateFlow(ScreenState.UNLOCK_PASSCODE)
    val currentScreen: StateFlow<ScreenState> = _currentScreen.asStateFlow()

    private val _currentTab = MutableStateFlow(HubTab.CHATS)
    val currentTab: StateFlow<HubTab> = _currentTab.asStateFlow()

    private val _selectedContact = MutableStateFlow<Contact?>(null)
    val selectedContact: StateFlow<Contact?> = _selectedContact.asStateFlow()

    // Passcode Gate state
    private val _passcodeInput = MutableStateFlow("")
    val passcodeInput: StateFlow<String> = _passcodeInput.asStateFlow()

    private val _passcodeError = MutableStateFlow<String?>(null)
    val passcodeError: StateFlow<String?> = _passcodeError.asStateFlow()

    // Face Scan state
    private val _faceScanStatus = MutableStateFlow(FaceScanStatus.IDLE)
    val faceScanStatus: StateFlow<FaceScanStatus> = _faceScanStatus.asStateFlow()

    private val _faceScanProgress = MutableStateFlow(0f)
    val faceScanProgress: StateFlow<Float> = _faceScanProgress.asStateFlow()

    // Voice message recording
    private val _isRecordingVoice = MutableStateFlow(false)
    val isRecordingVoice: StateFlow<Boolean> = _isRecordingVoice.asStateFlow()

    private val _recordingSeconds = MutableStateFlow(0)
    val recordingSeconds: StateFlow<Int> = _recordingSeconds.asStateFlow()

    private var voiceRecordJob: Job? = null
    private var faceScanJob: Job? = null

    init {
        // Observe call changes to switch screens
        viewModelScope.launch {
            repository.activeCall.collect { call ->
                if (call != null) {
                    when (call.callType) {
                        CallType.VOICE -> _currentScreen.value = ScreenState.VOICE_CALL
                        CallType.VIDEO -> _currentScreen.value = ScreenState.VIDEO_CALL
                    }
                } else if (_currentScreen.value == ScreenState.VOICE_CALL || _currentScreen.value == ScreenState.VIDEO_CALL) {
                    // Call ended, return to previous
                    _currentScreen.value = if (_selectedContact.value != null) ScreenState.CHAT else ScreenState.MAIN_HUB
                }
            }
        }
    }

    // Passcode handling
    fun onPasscodeChange(code: String) {
        _passcodeInput.value = code
        _passcodeError.value = null
    }

    fun submitPasscode() {
        val entered = _passcodeInput.value.trim()
        if (repository.verifyPasscode(entered)) {
            _passcodeError.value = null
            if (identity.value.requireFaceUnlock) {
                _currentScreen.value = ScreenState.UNLOCK_FACE
                startFaceScan()
            } else {
                _currentScreen.value = ScreenState.MAIN_HUB
            }
        } else {
            _passcodeError.value = "Incorrect Key! (Hint: Master Passcode is '${identity.value.masterPassword}')"
        }
    }

    fun autoFillMasterKey() {
        _passcodeInput.value = identity.value.masterPassword
        _passcodeError.value = null
    }

    // Face Scan handling
    fun startFaceScan() {
        faceScanJob?.cancel()
        _faceScanStatus.value = FaceScanStatus.SCANNING
        _faceScanProgress.value = 0f

        faceScanJob = viewModelScope.launch {
            for (i in 1..20) {
                delay(120)
                _faceScanProgress.value = i / 20f
                if (i == 10) {
                    _faceScanStatus.value = FaceScanStatus.ALIGNED
                }
            }
            _faceScanStatus.value = FaceScanStatus.VERIFIED
            delay(500)
            repository.verifyFaceScan()
            _currentScreen.value = ScreenState.MAIN_HUB
            _faceScanStatus.value = FaceScanStatus.IDLE
        }
    }

    fun openFaceScanTest() {
        _currentScreen.value = ScreenState.UNLOCK_FACE
        startFaceScan()
    }

    fun skipOrBypassFaceScan() {
        faceScanJob?.cancel()
        repository.verifyFaceScan()
        _currentScreen.value = ScreenState.MAIN_HUB
    }

    fun lockApp() {
        faceScanJob?.cancel()
        repository.lockApp()
        _passcodeInput.value = ""
        _passcodeError.value = null
        _faceScanStatus.value = FaceScanStatus.IDLE
        _currentScreen.value = ScreenState.UNLOCK_PASSCODE
    }

    // Navigation
    fun setTab(tab: HubTab) {
        _currentTab.value = tab
    }

    fun openChat(contact: Contact) {
        _selectedContact.value = contact
        _currentScreen.value = ScreenState.CHAT
    }

    fun closeChat() {
        _selectedContact.value = null
        _currentScreen.value = ScreenState.MAIN_HUB
    }

    // Messages
    fun sendMessage(text: String) {
        val contact = _selectedContact.value ?: return
        if (text.isBlank()) return
        repository.sendMessage(contact.id, text.trim())
    }

    fun sendVoiceNote() {
        val contact = _selectedContact.value ?: return
        val secs = _recordingSeconds.value.coerceAtLeast(3)
        repository.sendMessage(
            contactId = contact.id,
            text = "🔒 Encrypted Voice Message (${secs}s)",
            mediaType = MediaType.AUDIO_NOTE,
            audioDuration = secs
        )
        _isRecordingVoice.value = false
        voiceRecordJob?.cancel()
    }

    fun startVoiceRecording() {
        _isRecordingVoice.value = true
        _recordingSeconds.value = 0
        voiceRecordJob?.cancel()
        voiceRecordJob = viewModelScope.launch {
            var counter = 0
            while (_isRecordingVoice.value) {
                delay(1000)
                counter++
                _recordingSeconds.value = counter
            }
        }
    }

    fun cancelVoiceRecording() {
        _isRecordingVoice.value = false
        voiceRecordJob?.cancel()
    }

    fun sendPhotoMessage(caption: String, photoUri: String? = null) {
        val contact = _selectedContact.value ?: return
        repository.sendMessage(
            contactId = contact.id,
            text = caption.ifBlank { "🔒 Encrypted Photo Asset" },
            mediaType = MediaType.IMAGE,
            mediaUri = photoUri ?: "sample_encrypted_photo"
        )
    }

    fun sendVideoMessage(caption: String, durationSecs: Int = 12) {
        val contact = _selectedContact.value ?: return
        repository.sendMessage(
            contactId = contact.id,
            text = caption.ifBlank { "🔒 Encrypted Video (${durationSecs}s)" },
            mediaType = MediaType.VIDEO,
            videoDuration = durationSecs
        )
    }

    fun createGroup(name: String, members: List<String>, avatarId: String) {
        val newGroup = repository.createGroup(name, members, avatarId)
        openChat(newGroup)
    }

    fun deleteAllChats() {
        repository.deleteAllChats()
    }

    fun sendMediaAttachment(caption: String) {
        sendPhotoMessage(caption)
    }

    fun setDisappearingTimer(seconds: Int) {
        val contact = _selectedContact.value ?: return
        repository.setDisappearingTimer(contact.id, seconds)
        _selectedContact.value = contact.copy(disappearingDurationSeconds = seconds)
    }

    fun clearChat() {
        val contact = _selectedContact.value ?: return
        repository.clearChat(contact.id)
    }

    // Calling
    fun startVoiceCall(contact: Contact? = _selectedContact.value) {
        contact?.let { repository.startCall(it, CallType.VOICE) }
    }

    fun startVideoCall(contact: Contact? = _selectedContact.value) {
        contact?.let { repository.startCall(it, CallType.VIDEO) }
    }

    fun simulateIncomingCall(type: CallType) {
        repository.simulateIncomingCall(type)
    }

    fun acceptIncomingCall() {
        repository.acceptIncomingCall()
    }

    fun declineIncomingCall() {
        repository.declineIncomingCall()
    }

    fun toggleMute() = repository.toggleMute()
    fun toggleSpeaker() = repository.toggleSpeaker()
    fun toggleVideo() = repository.toggleVideo()
    fun flipCamera() = repository.flipCamera()
    fun endCall() = repository.endCall()

    // Identity and Contacts
    fun updateProfile(name: String, status: String, avatarId: String, customUri: String?) {
        repository.updateProfile(name, status, avatarId, customUri)
    }

    fun updateMasterPassword(newPass: String) {
        repository.updateMasterPassword(newPass)
    }

    fun setRequireFaceUnlock(enabled: Boolean) {
        repository.setRequireFaceUnlock(enabled)
    }

    fun addContact(name: String, tag: String) {
        val newContact = repository.addContact(name, tag)
        openChat(newContact)
    }

    fun zeroizeAllData() {
        repository.zeroizeAllData()
        _currentScreen.value = ScreenState.UNLOCK_PASSCODE
    }
}
