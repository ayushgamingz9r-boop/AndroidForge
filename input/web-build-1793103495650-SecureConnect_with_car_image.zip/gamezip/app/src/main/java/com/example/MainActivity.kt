package com.example

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.CipherViewModel
import com.example.ui.ScreenState
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.FaceScanScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.IncomingCallOverlay
import com.example.ui.screens.UnlockScreen
import com.example.ui.screens.VideoCallScreen
import com.example.ui.screens.VoiceCallScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val viewModel: CipherViewModel = viewModel()
                val currentScreen by viewModel.currentScreen.collectAsState()
                val incomingCall by viewModel.incomingCall.collectAsState()
                val identity by viewModel.identity.collectAsState()

                // Security flag for anti-screenshot if enabled
                if (identity.antiScreenshot) {
                    window.setFlags(
                        WindowManager.LayoutParams.FLAG_SECURE,
                        WindowManager.LayoutParams.FLAG_SECURE
                    )
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    Crossfade(
                        targetState = currentScreen,
                        label = "screenTransition"
                    ) { screen ->
                        when (screen) {
                            ScreenState.UNLOCK_PASSCODE -> UnlockScreen(viewModel)
                            ScreenState.UNLOCK_FACE -> FaceScanScreen(viewModel)
                            ScreenState.MAIN_HUB -> HomeScreen(viewModel)
                            ScreenState.CHAT -> ChatScreen(viewModel)
                            ScreenState.VOICE_CALL -> VoiceCallScreen(viewModel)
                            ScreenState.VIDEO_CALL -> VideoCallScreen(viewModel)
                        }
                    }

                    // Global Incoming Call Alert Overlay
                    IncomingCallOverlay(
                        incomingCall = incomingCall,
                        onAccept = { viewModel.acceptIncomingCall() },
                        onDecline = { viewModel.declineIncomingCall() }
                    )
                }
            }
        }
    }
}
