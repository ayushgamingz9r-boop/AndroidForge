package com.example.model

enum class MediaType {
    NONE,
    IMAGE,
    VIDEO,
    AUDIO_NOTE,
    SECURE_FILE
}

enum class DeliveryStatus {
    SENDING,
    SENT,
    DELIVERED,
    READ
}

enum class CallType {
    VOICE,
    VIDEO
}

enum class CallDirection {
    INCOMING,
    OUTGOING
}

enum class CallStatus {
    DIALING,
    RINGING,
    CONNECTING_HANDSHAKE,
    ACTIVE_ENCRYPTED,
    ENDED
}

data class UserIdentity(
    val id: String = "USR-770921",
    val username: String = "Aayush Cipher",
    val tag: String = "@aayush_sec#7709",
    val avatarId: String = "agent_stealth",
    val customAvatarUri: String? = null,
    val status: String = "CipherShield Enclave • Zero-Knowledge",
    val publicKey: String = "e2e_curve25519_8f9a2e1d00c3b4",
    val fingerprint: String = "7A9F 1104 E892 00BC 4921",
    val masterPassword: String = "CIPHER#9900",
    val requireFaceUnlock: Boolean = false,
    val isFaceEnrolled: Boolean = true,
    val antiScreenshot: Boolean = false,
    val blockGallerySave: Boolean = true // Media strictly sandboxed in app, never exported to device gallery
)

data class Contact(
    val id: String,
    val name: String,
    val tag: String,
    val avatarId: String,
    val customAvatarUri: String? = null,
    val status: String,
    val isOnline: Boolean,
    val lastSeen: String = "Online via Tor/Mesh",
    val fingerprint: String,
    val unreadCount: Int = 0,
    val disappearingDurationSeconds: Int = 0, // 0 = off, 10, 60, 3600
    val verified: Boolean = true,
    val isGroup: Boolean = false,
    val groupMembers: List<String> = emptyList(),
    val enclavePasscode: String = "CIPHER#9900" // Bound to authorized password enclave
)

data class Message(
    val id: String,
    val chatId: String,
    val senderId: String,
    val senderName: String,
    val text: String,
    val cipherText: String, // Base64 encrypted payload representation
    val timestamp: Long = System.currentTimeMillis(),
    val timeFormatted: String,
    val isFromMe: Boolean,
    val mediaType: MediaType = MediaType.NONE,
    val mediaUri: String? = null,
    val mediaCaption: String? = null,
    val audioDurationSeconds: Int = 0,
    val videoDurationSeconds: Int = 0,
    val isEncrypted: Boolean = true,
    val savedInGallery: Boolean = false, // Strictly false: never stored in Android Gallery
    val encryptionKeyId: String = "AES-256-GCM / Ratchet-V2",
    val deliveryStatus: DeliveryStatus = DeliveryStatus.READ,
    val expiresAt: Long? = null
)

data class CallState(
    val callId: String,
    val contact: Contact,
    val callType: CallType,
    val direction: CallDirection,
    val status: CallStatus,
    val durationSeconds: Int = 0,
    val isMuted: Boolean = false,
    val isSpeakerOn: Boolean = true,
    val isVideoEnabled: Boolean = true,
    val isFrontCamera: Boolean = true,
    val encryptionFingerprint: String = "AES-256 SRTP • DTLS-1.3",
    val audioQuality: String = "Opus HD 48kHz (E2EE)",
    val videoQuality: String = "1080p 60fps (E2EE)"
)

data class CallLog(
    val id: String,
    val contact: Contact,
    val callType: CallType,
    val timestamp: Long,
    val durationFormatted: String,
    val wasIncoming: Boolean,
    val wasMissed: Boolean
)

data class AvatarOption(
    val id: String,
    val name: String,
    val emoji: String,
    val accentHex: Long
)
