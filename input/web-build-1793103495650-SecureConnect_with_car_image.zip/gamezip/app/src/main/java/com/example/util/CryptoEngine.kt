package com.example.util

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import kotlin.random.Random

object CryptoEngine {
    private val secureRandom = SecureRandom()

    fun generateUniqueTag(username: String): String {
        val sanitized = username.lowercase().replace(" ", "_").filter { it.isLetterOrDigit() || it == '_' }
        val randomNum = 1000 + Random.nextInt(9000)
        return "@${sanitized.ifEmpty { "cipher" }}#$randomNum"
    }

    fun generateFingerprint(): String {
        val bytes = ByteArray(10)
        secureRandom.nextBytes(bytes)
        return bytes.joinToString(" ") { String.format("%02X", it) }
    }

    fun encryptPayload(plainText: String): String {
        // Generates realistic encrypted ciphertext representation with AES-GCM IV and payload
        val iv = ByteArray(12)
        secureRandom.nextBytes(iv)
        val salt = "AES256GCM"
        val raw = "$salt:$plainText:${System.currentTimeMillis()}"
        val encoded = Base64.encodeToString(raw.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        val ivHex = iv.joinToString("") { String.format("%02x", it) }
        return "e2e:iv$ivHex:$encoded"
    }

    fun hashPassword(password: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(password.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { String.format("%02x", it) }
    }

    fun formatDuration(seconds: Int): String {
        val mins = seconds / 60
        val secs = seconds % 60
        return String.format("%02d:%02d", mins, secs)
    }
}
