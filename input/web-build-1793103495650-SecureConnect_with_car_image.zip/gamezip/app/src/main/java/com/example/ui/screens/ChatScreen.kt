package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NoPhotography
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Contact
import com.example.model.MediaType
import com.example.model.Message
import com.example.ui.CipherViewModel
import com.example.ui.components.AvatarBadge
import com.example.ui.components.EncryptedBadge
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberError
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberSecondary
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberSurfaceVariant

@Composable
fun ChatScreen(viewModel: CipherViewModel) {
    val contact = viewModel.selectedContact.collectAsState().value ?: return
    val messagesMap by viewModel.messages.collectAsState()
    val chatMessages = messagesMap[contact.id] ?: emptyList()
    val isRecordingVoice by viewModel.isRecordingVoice.collectAsState()
    val recordingSeconds by viewModel.recordingSeconds.collectAsState()

    var inputText by remember { mutableStateOf("") }
    var showSafetyDialog by remember { mutableStateOf(false) }
    var showOptionsMenu by remember { mutableStateOf(false) }
    var showAttachmentMenu by remember { mutableStateOf(false) }
    var viewingVideoMessage by remember { mutableStateOf<Message?>(null) }
    var viewingPhotoMessage by remember { mutableStateOf<Message?>(null) }
    var showSendVideoPrompt by remember { mutableStateOf(false) }
    var showSendPhotoPrompt by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()

    BackHandler {
        viewModel.closeChat()
    }

    LaunchedEffect(chatMessages.size) {
        if (chatMessages.isNotEmpty()) {
            listState.animateScrollToItem(chatMessages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        // Chat Top Bar
        ChatTopBar(
            contact = contact,
            onBack = { viewModel.closeChat() },
            onVoiceCall = { viewModel.startVoiceCall(contact) },
            onVideoCall = { viewModel.startVideoCall(contact) },
            onShowSafety = { showSafetyDialog = true },
            onToggleOptions = { showOptionsMenu = !showOptionsMenu }
        )

        DropdownMenu(
            expanded = showOptionsMenu,
            onDismissRequest = { showOptionsMenu = false },
            modifier = Modifier.background(CyberSurface)
        ) {
            DropdownMenuItem(
                text = { Text("Safety Numbers Fingerprint", color = CyberPrimary) },
                onClick = {
                    showOptionsMenu = false
                    showSafetyDialog = true
                }
            )
            DropdownMenuItem(
                text = { Text("Disappearing: 10 seconds", color = Color.White) },
                onClick = {
                    viewModel.setDisappearingTimer(10)
                    showOptionsMenu = false
                }
            )
            DropdownMenuItem(
                text = { Text("Disappearing: OFF", color = Color.White) },
                onClick = {
                    viewModel.setDisappearingTimer(0)
                    showOptionsMenu = false
                }
            )
            DropdownMenuItem(
                text = { Text("Clear Chat History", color = CyberError) },
                onClick = {
                    viewModel.clearChat()
                    showOptionsMenu = false
                }
            )
        }

        // Zero Gallery Save Banner requested by user
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = CyberSurfaceVariant.copy(alpha = 0.8f),
            border = androidx.compose.foundation.BorderStroke(0.5.dp, CyberPrimary.copy(alpha = 0.3f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = CyberPrimary,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "No Phone # • Photos & Videos Never Saved to Gallery",
                    fontSize = 11.sp,
                    color = CyberPrimary,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Message List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(chatMessages, key = { it.id }) { msg ->
                MessageBubble(
                    message = msg,
                    onOpenVideo = { viewingVideoMessage = msg },
                    onOpenPhoto = { viewingPhotoMessage = msg }
                )
            }
        }

        // Bottom Input Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = CyberSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberOutline)
        ) {
            if (isRecordingVoice) {
                // Active Voice Recording
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(CyberError)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Recording Encrypted Audio (${recordingSeconds}s)...",
                            color = CyberError,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Row {
                        IconButton(onClick = { viewModel.cancelVoiceRecording() }) {
                            Icon(Icons.Default.Close, contentDescription = "Cancel", tint = Color.Gray)
                        }
                        IconButton(onClick = { viewModel.sendVoiceNote() }) {
                            Icon(Icons.Default.Stop, contentDescription = "Send Audio", tint = CyberPrimary)
                        }
                    }
                }
            } else {
                Column {
                    // Attachment Selector Sheet
                    AnimatedVisibility(visible = showAttachmentMenu) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CyberSurfaceElevated)
                                .padding(vertical = 10.dp, horizontal = 8.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            TextButton(onClick = {
                                showAttachmentMenu = false
                                showSendPhotoPrompt = true
                            }) {
                                Icon(Icons.Default.Image, contentDescription = null, tint = CyberPrimary)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Photo", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            TextButton(onClick = {
                                showAttachmentMenu = false
                                showSendVideoPrompt = true
                            }) {
                                Icon(Icons.Default.Videocam, contentDescription = null, tint = CyberSecondary)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Video", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            TextButton(onClick = {
                                showAttachmentMenu = false
                                viewModel.sendMessage("🔒 Encrypted Key Package (.sig)")
                            }) {
                                Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFFF59E0B))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("File", color = Color.White, fontSize = 12.sp)
                            }
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { showAttachmentMenu = !showAttachmentMenu }) {
                            Icon(
                                imageVector = Icons.Default.AttachFile,
                                contentDescription = "Attach",
                                tint = if (showAttachmentMenu) CyberPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        OutlinedTextField(
                            value = inputText,
                            onValueChange = { inputText = it },
                            placeholder = { Text("Write encrypted message...") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("message_input"),
                            shape = RoundedCornerShape(20.dp),
                            singleLine = false,
                            maxLines = 4,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberPrimary,
                                unfocusedBorderColor = CyberOutline,
                                unfocusedContainerColor = CyberSurfaceVariant,
                                focusedContainerColor = CyberSurfaceVariant
                            )
                        )

                        Spacer(modifier = Modifier.width(6.dp))

                        if (inputText.isNotBlank()) {
                            IconButton(
                                onClick = {
                                    viewModel.sendMessage(inputText)
                                    inputText = ""
                                },
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(CyberPrimary)
                                    .testTag("send_message_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "Send",
                                    tint = CyberBackground,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        } else {
                            IconButton(
                                onClick = { viewModel.startVoiceRecording() },
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(CyberSurfaceElevated)
                                    .testTag("record_voice_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "Record Voice",
                                    tint = CyberPrimary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Encrypted In-App Video Player Dialog
    if (viewingVideoMessage != null) {
        EncryptedVideoPlayerDialog(
            message = viewingVideoMessage!!,
            onDismiss = { viewingVideoMessage = null }
        )
    }

    // Encrypted In-App Photo Viewer Dialog
    if (viewingPhotoMessage != null) {
        EncryptedPhotoViewerDialog(
            message = viewingPhotoMessage!!,
            onDismiss = { viewingPhotoMessage = null }
        )
    }

    // Send Photo Dialog
    if (showSendPhotoPrompt) {
        SendPhotoDialog(
            onDismiss = { showSendPhotoPrompt = false },
            onSend = { caption ->
                viewModel.sendPhotoMessage(caption)
                showSendPhotoPrompt = false
            }
        )
    }

    // Send Video Dialog
    if (showSendVideoPrompt) {
        SendVideoDialog(
            onDismiss = { showSendVideoPrompt = false },
            onSend = { caption, duration ->
                viewModel.sendVideoMessage(caption, duration)
                showSendVideoPrompt = false
            }
        )
    }

    if (showSafetyDialog) {
        SafetyNumbersDialog(contact = contact, onDismiss = { showSafetyDialog = false })
    }
}

@Composable
private fun ChatTopBar(
    contact: Contact,
    onBack: () -> Unit,
    onVoiceCall: () -> Unit,
    onVideoCall: () -> Unit,
    onShowSafety: () -> Unit,
    onToggleOptions: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = CyberSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberOutline)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White
                )
            }

            AvatarBadge(
                avatarId = contact.avatarId,
                size = 40.dp,
                showOnlineStatus = !contact.isGroup,
                isOnline = contact.isOnline
            )

            Spacer(modifier = Modifier.width(10.dp))

            Column(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onShowSafety() }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = contact.name,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (contact.isGroup) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = CyberSecondary.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "GROUP",
                                fontSize = 8.sp,
                                color = CyberSecondary,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
                Text(
                    text = if (contact.isGroup) "${contact.groupMembers.size} members (AES-GCM)" else "${contact.tag} • Online",
                    fontSize = 11.sp,
                    color = CyberPrimary,
                    fontFamily = FontFamily.Monospace
                )
            }

            IconButton(
                onClick = onVoiceCall,
                modifier = Modifier.testTag("voice_call_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = "Encrypted Voice Call",
                    tint = CyberPrimary
                )
            }

            IconButton(
                onClick = onVideoCall,
                modifier = Modifier.testTag("video_call_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Videocam,
                    contentDescription = "Encrypted Video Call",
                    tint = CyberSecondary
                )
            }

            IconButton(onClick = onToggleOptions) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Options",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun MessageBubble(
    message: Message,
    onOpenVideo: () -> Unit,
    onOpenPhoto: () -> Unit
) {
    var showCipherPayload by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = if (message.isFromMe) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 300.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (message.isFromMe) 16.dp else 2.dp,
                        bottomEnd = if (message.isFromMe) 2.dp else 16.dp
                    )
                )
                .background(if (message.isFromMe) CyberSurfaceElevated else CyberSurfaceVariant)
                .border(
                    width = 1.dp,
                    color = if (message.isFromMe) CyberPrimary.copy(alpha = 0.4f) else CyberOutline,
                    shape = RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (message.isFromMe) 16.dp else 2.dp,
                        bottomEnd = if (message.isFromMe) 2.dp else 16.dp
                    )
                )
                .padding(10.dp)
        ) {
            // Sender label for group messages
            if (!message.isFromMe) {
                Text(
                    text = message.senderName,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberSecondary,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }

            // Video Message Bubble
            if (message.mediaType == MediaType.VIDEO) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(CyberBackground)
                        .border(1.dp, CyberSecondary, RoundedCornerShape(10.dp))
                        .clickable { onOpenVideo() },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(CyberSecondary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Play Video",
                                tint = CyberBackground,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Encrypted Video (${message.videoDurationSeconds}s)",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = CyberSurfaceElevated
                        ) {
                            Text(
                                text = "🔒 In-App Play Only • Blocked from Gallery",
                                color = CyberPrimary,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
            } else if (message.mediaType == MediaType.IMAGE) {
                // Photo Message Bubble
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(CyberBackground)
                        .border(1.dp, CyberPrimary, RoundedCornerShape(10.dp))
                        .clickable { onOpenPhoto() },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Image,
                            contentDescription = null,
                            tint = CyberPrimary,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "🔒 Encrypted Photo (Tap to view)",
                            fontSize = 11.sp,
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Sandboxed in app • Never in Gallery",
                            fontSize = 9.sp,
                            color = CyberPrimary
                        )
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
            } else if (message.mediaType == MediaType.AUDIO_NOTE) {
                // Audio note
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(CyberPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Play",
                            tint = CyberBackground,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Encrypted Voice Note (${message.audioDurationSeconds}s)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberPrimary
                        )
                        Text(
                            text = "Opus HD • AES-256 GCM",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Message text
            Text(
                text = message.text,
                color = Color.White,
                fontSize = 14.sp,
                lineHeight = 18.sp
            )

            // Peek cipher payload
            if (showCipherPayload) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    color = CyberBackground,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "CIPHER: ${message.cipherText}",
                        color = CyberPrimary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Footer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (showCipherPayload) "Hide Cipher" else "Peek Cipher",
                    fontSize = 9.sp,
                    color = CyberSecondary,
                    modifier = Modifier.clickable { showCipherPayload = !showCipherPayload }
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = message.timeFormatted,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (message.isFromMe) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.DoneAll,
                            contentDescription = "Read",
                            tint = CyberPrimary,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }
            }
        }
    }
}

// In-App Video Player Dialog (Plays inside app, NEVER saved to gallery)
@Composable
private fun EncryptedVideoPlayerDialog(
    message: Message,
    onDismiss: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "videoPlay")
    val progress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "vidProgress"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Videocam, contentDescription = null, tint = CyberSecondary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Encrypted In-App Video Player", color = Color.White, fontSize = 16.sp)
            }
        },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Video Screen simulation with digital cipher HUD
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black)
                        .border(1.5.dp, CyberSecondary, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    // Animated ambient scan waves
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawLine(
                            color = CyberSecondary.copy(alpha = 0.4f),
                            start = Offset(0f, size.height * progress),
                            end = Offset(size.width, size.height * progress),
                            strokeWidth = 2.dp.toPx()
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.PlayCircle,
                            contentDescription = null,
                            tint = CyberSecondary,
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "DECRYPTING & STREAMING...",
                            color = CyberPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Resolution: 1080p • 60fps • Memory Stream",
                            color = Color.LightGray,
                            fontSize = 10.sp
                        )
                    }

                    // Watermark: Blocked from Gallery
                    Surface(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp),
                        shape = RoundedCornerShape(4.dp),
                        color = CyberBackground.copy(alpha = 0.8f)
                    ) {
                        Text(
                            text = "NOT IN GALLERY",
                            color = CyberError,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = CyberSecondary,
                    trackColor = CyberSurfaceElevated
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "🔒 Security Notice: Yeh video sirf app ke encrypted memory sandbox mein chal rahi hai aur device ki phone gallery (DCIM / MediaStore) mein bilkul save nahi hogi.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = CyberSecondary, contentColor = CyberBackground)
            ) {
                Text("CLOSE VIDEO", fontWeight = FontWeight.Bold)
            }
        },
        containerColor = CyberSurface
    )
}

// In-App Photo Viewer Dialog (Never in Gallery)
@Composable
private fun EncryptedPhotoViewerDialog(
    message: Message,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Image, contentDescription = null, tint = CyberPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Encrypted Sandboxed Photo", color = Color.White, fontSize = 16.sp)
            }
        },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(CyberBackground)
                        .border(1.5.dp, CyberPrimary, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = CyberPrimary,
                            modifier = Modifier.size(52.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "ENCRYPTED PHOTO ASSET",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "AES-256 GCM Local Sandbox",
                            color = CyberSecondary,
                            fontSize = 11.sp
                        )
                    }

                    Surface(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 8.dp),
                        shape = RoundedCornerShape(6.dp),
                        color = CyberSurfaceElevated
                    ) {
                        Text(
                            text = "🛡️ Blocked from Phone Gallery",
                            color = CyberPrimary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Aapka photo strictly device memory me encrypted hai aur Gallery me export nahi hoga.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberBackground)
            ) {
                Text("DONE", fontWeight = FontWeight.Bold)
            }
        },
        containerColor = CyberSurface
    )
}

// Dialog to Send Photo
@Composable
private fun SendPhotoDialog(
    onDismiss: () -> Unit,
    onSend: (caption: String) -> Unit
) {
    var caption by remember { mutableStateOf("Encrypted Confidential Photo") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Send Encrypted Photo", color = Color.White) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Photo chat me bhej rahe hain. Yeh photo receiver ki gallery me save nahi hoga.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = caption,
                    onValueChange = { caption = it },
                    label = { Text("Photo Caption") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CyberPrimary)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSend(caption) },
                colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberBackground)
            ) {
                Text("SEND ENCRYPTED PHOTO", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color.White)
            }
        },
        containerColor = CyberSurface
    )
}

// Dialog to Send Video
@Composable
private fun SendVideoDialog(
    onDismiss: () -> Unit,
    onSend: (caption: String, duration: Int) -> Unit
) {
    var caption by remember { mutableStateOf("Encrypted Security Video [15s]") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Send Encrypted Video", color = Color.White) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Video transmission will be encrypted with AES-256 and will NOT be saved in any gallery.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = caption,
                    onValueChange = { caption = it },
                    label = { Text("Video Caption") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CyberSecondary)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSend(caption, 15) },
                colors = ButtonDefaults.buttonColors(containerColor = CyberSecondary, contentColor = CyberBackground)
            ) {
                Text("SEND ENCRYPTED VIDEO", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color.White)
            }
        },
        containerColor = CyberSurface
    )
}

@Composable
private fun SafetyNumbersDialog(contact: Contact, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Security, contentDescription = null, tint = CyberPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Safety Numbers Verification", color = Color.White, fontSize = 16.sp)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Compare these safety numbers with ${contact.name} to confirm this end-to-end encrypted session is authentic:",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = CyberSurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberPrimary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = contact.fingerprint,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberPrimary,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(12.dp)
                    )
                }

                Text(
                    text = "Status: Cryptographically Verified (Curve25519 Ephemeral Handshake)",
                    fontSize = 11.sp,
                    color = CyberSecondary
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("CLOSE", color = CyberPrimary, fontWeight = FontWeight.Bold)
            }
        },
        containerColor = CyberSurface
    )
}
