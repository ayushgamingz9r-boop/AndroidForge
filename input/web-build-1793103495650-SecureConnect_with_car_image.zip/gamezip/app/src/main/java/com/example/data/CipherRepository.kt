package com.example.data

import com.example.model.AvatarOption
import com.example.model.CallDirection
import com.example.model.CallLog
import com.example.model.CallState
import com.example.model.CallStatus
import com.example.model.CallType
import com.example.model.Contact
import com.example.model.DeliveryStatus
import com.example.model.MediaType
import com.example.model.Message
import com.example.model.UserIdentity
import com.example.util.CryptoEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class CipherRepository(
    private val context: android.content.Context? = null,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Main)
) {
    private val syncManager = context?.let { FirestoreSyncManager(it, scope) }

    val avatarPresets = listOf(
        AvatarOption("agent_stealth", "Ghost Operator", "🕶️", 0xFF00E599),
        AvatarOption("cyber_samurai", "Neon Ronin", "⚔️", 0xFF00E5FF),
        AvatarOption("crypto_raven", "Shadow Raven", "🦅", 0xFF8B5CF6),
        AvatarOption("enclave_shield", "Aegis Core", "🛡️", 0xFF10B981),
        AvatarOption("glitch_phantom", "Null Hacker", "👾", 0xFFF59E0B),
        AvatarOption("bio_cyber", "Neural Net", "🧬", 0xFFEC4899),
        AvatarOption("stealth_fox", "Cipher Fox", "🦊", 0xFFFF6B6B),
        AvatarOption("quantum_core", "Quantum Orb", "⚛️", 0xFF6366F1)
    )

    private val _identity = MutableStateFlow(
        UserIdentity(
            id = "USR-770921",
            username = "Aayush Cipher",
            tag = "@aayush_sec#7709",
            avatarId = "agent_stealth",
            status = "CipherShield Enclave • Developed By Ayush",
            publicKey = "0x8F9A2E1D...E2EE",
            fingerprint = "91A4 88C0 23FE 1109 7721",
            masterPassword = "CIPHER#9900",
            requireFaceUnlock = false,
            isFaceEnrolled = true,
            blockGallerySave = true
        )
    )
    val identity: StateFlow<UserIdentity> = _identity.asStateFlow()

    private val _isPasscodeUnlocked = MutableStateFlow(false)
    val isPasscodeUnlocked: StateFlow<Boolean> = _isPasscodeUnlocked.asStateFlow()

    private val _isFaceScanVerified = MutableStateFlow(false)
    val isFaceScanVerified: StateFlow<Boolean> = _isFaceScanVerified.asStateFlow()

    private val _activeEnclavePasscode = MutableStateFlow("CIPHER#9900")
    val activeEnclavePasscode: StateFlow<String> = _activeEnclavePasscode.asStateFlow()

    private val _contacts = MutableStateFlow<List<Contact>>(emptyList())
    // Visible contacts filtered by active passcode enclave
    val contacts: StateFlow<List<Contact>> = combine(_contacts, _activeEnclavePasscode) { list, enclave ->
        list.filter { it.enclavePasscode.equals(enclave, ignoreCase = true) }
    }.stateIn(scope, SharingStarted.Eagerly, emptyList())

    private val _messages = MutableStateFlow<Map<String, List<Message>>>(emptyMap())
    val messages: StateFlow<Map<String, List<Message>>> = _messages.asStateFlow()

    private val _activeCall = MutableStateFlow<CallState?>(null)
    val activeCall: StateFlow<CallState?> = _activeCall.asStateFlow()

    private val _incomingCall = MutableStateFlow<CallState?>(null)
    val incomingCall: StateFlow<CallState?> = _incomingCall.asStateFlow()

    private val _callLogs = MutableStateFlow<List<CallLog>>(emptyList())
    val callLogs: StateFlow<List<CallLog>> = _callLogs.asStateFlow()

    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    init {
        seedInitialData()
    }

    private fun seedInitialData() {
        val initialContacts = listOf(
            Contact(
                id = "G-01",
                name = "Apex Ghost Squad",
                tag = "@ghost_squad_group",
                avatarId = "enclave_shield",
                status = "Encrypted Tactical Group • 4 Members",
                isOnline = true,
                fingerprint = "8899 AABB CCDD EEFF 0011",
                unreadCount = 2,
                isGroup = true,
                groupMembers = listOf("Aayush Cipher (Admin)", "Sarah Vance", "Ghost Protocol", "Vikram Sharma"),
                enclavePasscode = "CIPHER#9900"
            ),
            Contact(
                id = "C-01",
                name = "Sarah Vance",
                tag = "@sarah_ops#1044",
                avatarId = "cyber_samurai",
                status = "Zero Knowledge Protocol Active",
                isOnline = true,
                fingerprint = "4A91 22E0 89B1 5562 1044",
                unreadCount = 1,
                disappearingDurationSeconds = 60,
                enclavePasscode = "CIPHER#9900"
            ),
            Contact(
                id = "C-02",
                name = "Ghost Protocol",
                tag = "@phantom_99#8821",
                avatarId = "glitch_phantom",
                status = "Untraceable • Ephemeral Keys",
                isOnline = true,
                fingerprint = "9982 7711 CC00 FF91 8821",
                unreadCount = 0,
                enclavePasscode = "CIPHER#9900"
            ),
            Contact(
                id = "C-03",
                name = "Vikram Sharma",
                tag = "@vikram_sec#4550",
                avatarId = "crypto_raven",
                status = "Signal Verified • No SIM / No Cloud",
                isOnline = false,
                lastSeen = "Last active 15m ago",
                fingerprint = "3B12 EE88 9012 4471 4550",
                unreadCount = 0,
                enclavePasscode = "CIPHER#9900"
            ),
            Contact(
                id = "C-04",
                name = "Enclave Security HQ",
                tag = "@enclave_hq#0010",
                avatarId = "bio_cyber",
                status = "Encrypted Mesh Dispatcher",
                isOnline = true,
                fingerprint = "0010 99AA BBCC DDEE 0010",
                unreadCount = 0,
                enclavePasscode = "CIPHER#9900"
            )
        )
        _contacts.value = initialContacts

        initialContacts.forEach { contact ->
            syncManager?.startListeningToChannel(contact.id, _identity.value.id) { remoteMsg ->
                handleRemoteMessage(remoteMsg)
            }
        }

        val now = System.currentTimeMillis()
        val g1Messages = listOf(
            Message(
                id = "GM-01",
                chatId = "G-01",
                senderId = "C-01",
                senderName = "Sarah Vance",
                text = "Welcome to our private group developed by Ayush. All media is sandboxed in encrypted storage.",
                cipherText = CryptoEngine.encryptPayload("Welcome to our private group developed by Ayush."),
                timestamp = now - 7200000,
                timeFormatted = "09:10",
                isFromMe = false
            ),
            Message(
                id = "GM-02",
                chatId = "G-01",
                senderId = "USR-770921",
                senderName = "Aayush Cipher",
                text = "Notice: Photos and videos shared here are strictly blocked from phone gallery.",
                cipherText = CryptoEngine.encryptPayload("Photos and videos shared here are strictly blocked from phone gallery."),
                timestamp = now - 5400000,
                timeFormatted = "09:40",
                isFromMe = true,
                mediaType = MediaType.IMAGE,
                savedInGallery = false
            ),
            Message(
                id = "GM-03",
                chatId = "G-01",
                senderId = "C-02",
                senderName = "Ghost Protocol",
                text = "Encrypted Recon Video Transmission [18s]",
                cipherText = CryptoEngine.encryptPayload("Encrypted Recon Video Transmission"),
                timestamp = now - 3600000,
                timeFormatted = "10:15",
                isFromMe = false,
                mediaType = MediaType.VIDEO,
                videoDurationSeconds = 18,
                savedInGallery = false
            )
        )

        val c1Messages = listOf(
            Message(
                id = "M-01",
                chatId = "C-01",
                senderId = "C-01",
                senderName = "Sarah Vance",
                text = "Welcome to CipherShield. Developed By Ayush with zero-SIM anonymous architecture.",
                cipherText = CryptoEngine.encryptPayload("Welcome to CipherShield. Developed By Ayush."),
                timestamp = now - 3600000,
                timeFormatted = "10:15",
                isFromMe = false
            ),
            Message(
                id = "M-02",
                chatId = "C-01",
                senderId = "USR-770921",
                senderName = "Aayush Cipher",
                text = "Verified. Photos & videos stay in-app and never export to Android Gallery.",
                cipherText = CryptoEngine.encryptPayload("Verified. Photos & videos stay in-app and never export to Android Gallery."),
                timestamp = now - 3400000,
                timeFormatted = "10:18",
                isFromMe = true,
                deliveryStatus = DeliveryStatus.READ
            ),
            Message(
                id = "M-03",
                chatId = "C-01",
                senderId = "C-01",
                senderName = "Sarah Vance",
                text = "Encrypted voice & video calling ready. Ready whenever you are.",
                cipherText = CryptoEngine.encryptPayload("Encrypted voice & video calling ready."),
                timestamp = now - 1800000,
                timeFormatted = "10:32",
                isFromMe = false
            )
        )

        val c2Messages = listOf(
            Message(
                id = "M-11",
                chatId = "C-02",
                senderId = "C-02",
                senderName = "Ghost Protocol",
                text = "AES-256 GCM authenticated payload verified. Group channels active.",
                cipherText = CryptoEngine.encryptPayload("AES-256 GCM authenticated payload verified."),
                timestamp = now - 7200000,
                timeFormatted = "09:05",
                isFromMe = false
            )
        )

        _messages.value = mapOf(
            "G-01" to g1Messages,
            "C-01" to c1Messages,
            "C-02" to c2Messages
        )

        _callLogs.value = listOf(
            CallLog(
                id = "CL-01",
                contact = initialContacts[1],
                callType = CallType.VIDEO,
                timestamp = now - 86400000,
                durationFormatted = "04:18",
                wasIncoming = true,
                wasMissed = false
            ),
            CallLog(
                id = "CL-02",
                contact = initialContacts[2],
                callType = CallType.VOICE,
                timestamp = now - 43200000,
                durationFormatted = "02:45",
                wasIncoming = false,
                wasMissed = false
            )
        )
    }

    fun verifyPasscode(input: String): Boolean {
        val matches = input.trim().equals(_identity.value.masterPassword.trim(), ignoreCase = true)
        if (matches) {
            _activeEnclavePasscode.value = input.trim()
            _isPasscodeUnlocked.value = true
        }
        return matches
    }

    fun verifyFaceScan(): Boolean {
        _isFaceScanVerified.value = true
        return true
    }

    fun lockApp() {
        _isPasscodeUnlocked.value = false
        _isFaceScanVerified.value = false
    }

    fun updateMasterPassword(newPass: String) {
        val trimmed = newPass.trim()
        _identity.update { it.copy(masterPassword = trimmed) }
        _activeEnclavePasscode.value = trimmed
        // Update current contacts to match new password enclave
        _contacts.update { list -> list.map { it.copy(enclavePasscode = trimmed) } }
    }

    fun updateProfile(username: String, status: String, avatarId: String, customUri: String? = null) {
        val newTag = CryptoEngine.generateUniqueTag(username)
        _identity.update {
            it.copy(
                username = username,
                tag = newTag,
                status = status,
                avatarId = avatarId,
                customAvatarUri = customUri
            )
        }
    }

    fun setRequireFaceUnlock(enabled: Boolean) {
        _identity.update { it.copy(requireFaceUnlock = enabled) }
    }

    fun setDisappearingTimer(contactId: String, seconds: Int) {
        _contacts.update { list ->
            list.map { if (it.id == contactId) it.copy(disappearingDurationSeconds = seconds) else it }
        }
    }

    fun addContact(name: String, customTag: String): Contact {
        val tag = if (customTag.startsWith("@")) customTag else "@$customTag"
        val newContact = Contact(
            id = "C-${UUID.randomUUID().toString().take(6)}",
            name = name.ifBlank { "Encrypted Contact" },
            tag = tag,
            avatarId = avatarPresets.random().id,
            status = "Direct P2P Encrypted Session",
            isOnline = true,
            fingerprint = CryptoEngine.generateFingerprint(),
            unreadCount = 0,
            enclavePasscode = _activeEnclavePasscode.value
        )
        _contacts.update { listOf(newContact) + it }
        syncManager?.startListeningToChannel(newContact.id, _identity.value.id) { remoteMsg ->
            handleRemoteMessage(remoteMsg)
        }
        return newContact
    }

    fun createGroup(name: String, memberNames: List<String>, avatarId: String): Contact {
        val groupTag = "@group_${name.lowercase().replace(" ", "_").filter { it.isLetterOrDigit() || it == '_' }}"
        val newGroup = Contact(
            id = "G-${UUID.randomUUID().toString().take(6)}",
            name = name.ifBlank { "Encrypted Group" },
            tag = groupTag,
            avatarId = avatarId,
            status = "Encrypted Group • ${memberNames.size + 1} Members",
            isOnline = true,
            fingerprint = CryptoEngine.generateFingerprint(),
            unreadCount = 0,
            isGroup = true,
            groupMembers = listOf("${_identity.value.username} (Creator)") + memberNames,
            enclavePasscode = _activeEnclavePasscode.value
        )
        _contacts.update { listOf(newGroup) + it }

        syncManager?.startListeningToChannel(newGroup.id, _identity.value.id) { remoteMsg ->
            handleRemoteMessage(remoteMsg)
        }

        // Initial welcome message in group
        val welcomeMsg = Message(
            id = "GM-${UUID.randomUUID().toString().take(8)}",
            chatId = newGroup.id,
            senderId = _identity.value.id,
            senderName = _identity.value.username,
            text = "Group created with end-to-end encryption. Photos and videos sent here are sandboxed and never saved to Gallery.",
            cipherText = CryptoEngine.encryptPayload("Group created with end-to-end encryption."),
            timeFormatted = timeFormat.format(Date()),
            isFromMe = true,
            savedInGallery = false
        )
        _messages.update { it + (newGroup.id to listOf(welcomeMsg)) }

        return newGroup
    }

    private fun handleRemoteMessage(msg: Message) {
        _messages.update { map ->
            val list = map[msg.chatId] ?: emptyList()
            if (list.none { it.id == msg.id }) {
                map + (msg.chatId to (list + msg))
            } else {
                map
            }
        }
    }

    fun sendMessage(
        contactId: String,
        text: String,
        mediaType: MediaType = MediaType.NONE,
        mediaUri: String? = null,
        audioDuration: Int = 0,
        videoDuration: Int = 0
    ) {
        val contact = _contacts.value.find { it.id == contactId } ?: return
        val currentList = _messages.value[contactId] ?: emptyList()
        val timeStr = timeFormat.format(Date())
        val msgId = "M-${UUID.randomUUID().toString().take(8)}"

        val newMessage = Message(
            id = msgId,
            chatId = contactId,
            senderId = _identity.value.id,
            senderName = _identity.value.username,
            text = text,
            cipherText = CryptoEngine.encryptPayload(text),
            timestamp = System.currentTimeMillis(),
            timeFormatted = timeStr,
            isFromMe = true,
            mediaType = mediaType,
            mediaUri = mediaUri,
            audioDurationSeconds = audioDuration,
            videoDurationSeconds = videoDuration,
            savedInGallery = false, // Media is NEVER saved to gallery
            deliveryStatus = DeliveryStatus.SENT
        )

        _messages.update { map ->
            map + (contactId to (currentList + newMessage))
        }

        // Publish to real-time online Firestore cloud relay
        syncManager?.publishMessage(newMessage, _activeEnclavePasscode.value)

        // Simulate delivery tick
        scope.launch {
            delay(500)
            updateMessageDelivery(contactId, msgId, DeliveryStatus.DELIVERED)
            delay(500)
            updateMessageDelivery(contactId, msgId, DeliveryStatus.READ)

            // Peer replies with encrypted message if not a group
            delay(1200)
            simulatePeerReply(contact)
        }
    }

    private fun updateMessageDelivery(contactId: String, messageId: String, status: DeliveryStatus) {
        _messages.update { map ->
            val list = map[contactId] ?: return@update map
            map + (contactId to list.map { if (it.id == messageId) it.copy(deliveryStatus = status) else it })
        }
    }

    private fun simulatePeerReply(contact: Contact) {
        val senderName = if (contact.isGroup) {
            contact.groupMembers.filterNot { it.contains("Creator") }.randomOrNull() ?: "Operative"
        } else {
            contact.name
        }

        val replies = listOf(
            "Encrypted packet received and stored in memory. Not saved to phone gallery.",
            "Signal confirmed. All streams DTLS-1.3 encrypted.",
            "Got your message! All clear on this node.",
            "Packet verified against our safety numbers: ${contact.fingerprint.take(9)}.",
            "Understood! Transmission secure."
        )
        val replyText = replies.random()
        val timeStr = timeFormat.format(Date())
        val replyMsg = Message(
            id = "M-${UUID.randomUUID().toString().take(8)}",
            chatId = contact.id,
            senderId = contact.id,
            senderName = senderName,
            text = replyText,
            cipherText = CryptoEngine.encryptPayload(replyText),
            timestamp = System.currentTimeMillis(),
            timeFormatted = timeStr,
            isFromMe = false,
            savedInGallery = false
        )

        _messages.update { map ->
            val current = map[contact.id] ?: emptyList()
            map + (contact.id to (current + replyMsg))
        }
    }

    fun clearChat(contactId: String) {
        _messages.update { map ->
            map + (contactId to emptyList())
        }
    }

    // 1-Click Delete All Chats feature!
    fun deleteAllChats() {
        _messages.value = emptyMap()
    }

    // Calling functionality
    fun startCall(contact: Contact, type: CallType) {
        val call = CallState(
            callId = UUID.randomUUID().toString(),
            contact = contact,
            callType = type,
            direction = CallDirection.OUTGOING,
            status = CallStatus.DIALING,
            durationSeconds = 0,
            isVideoEnabled = (type == CallType.VIDEO)
        )
        _activeCall.value = call

        scope.launch {
            delay(1000)
            _activeCall.update { it?.copy(status = CallStatus.RINGING) }
            delay(1200)
            _activeCall.update { it?.copy(status = CallStatus.CONNECTING_HANDSHAKE) }
            delay(800)
            _activeCall.update { it?.copy(status = CallStatus.ACTIVE_ENCRYPTED) }
            runCallTimer()
        }
    }

    fun simulateIncomingCall(type: CallType = CallType.VIDEO) {
        val caller = _contacts.value.firstOrNull { !it.isGroup } ?: _contacts.value.firstOrNull() ?: return
        val incoming = CallState(
            callId = UUID.randomUUID().toString(),
            contact = caller,
            callType = type,
            direction = CallDirection.INCOMING,
            status = CallStatus.RINGING,
            durationSeconds = 0,
            isVideoEnabled = (type == CallType.VIDEO)
        )
        _incomingCall.value = incoming
    }

    fun acceptIncomingCall() {
        val inc = _incomingCall.value ?: return
        _incomingCall.value = null
        _activeCall.value = inc.copy(status = CallStatus.CONNECTING_HANDSHAKE)

        scope.launch {
            delay(600)
            _activeCall.update { it?.copy(status = CallStatus.ACTIVE_ENCRYPTED) }
            runCallTimer()
        }
    }

    fun declineIncomingCall() {
        val inc = _incomingCall.value ?: return
        _incomingCall.value = null
        val log = CallLog(
            id = UUID.randomUUID().toString(),
            contact = inc.contact,
            callType = inc.callType,
            timestamp = System.currentTimeMillis(),
            durationFormatted = "Declined",
            wasIncoming = true,
            wasMissed = true
        )
        _callLogs.update { listOf(log) + it }
    }

    private fun runCallTimer() {
        scope.launch {
            while (_activeCall.value?.status == CallStatus.ACTIVE_ENCRYPTED) {
                delay(1000)
                _activeCall.update { call ->
                    call?.copy(durationSeconds = call.durationSeconds + 1)
                }
            }
        }
    }

    fun toggleMute() {
        _activeCall.update { it?.copy(isMuted = !(it.isMuted)) }
    }

    fun toggleSpeaker() {
        _activeCall.update { it?.copy(isSpeakerOn = !(it.isSpeakerOn)) }
    }

    fun toggleVideo() {
        _activeCall.update { it?.copy(isVideoEnabled = !(it.isVideoEnabled)) }
    }

    fun flipCamera() {
        _activeCall.update { it?.copy(isFrontCamera = !(it.isFrontCamera)) }
    }

    fun endCall() {
        val call = _activeCall.value ?: return
        val durationFormatted = CryptoEngine.formatDuration(call.durationSeconds)
        _activeCall.value = call.copy(status = CallStatus.ENDED)

        val log = CallLog(
            id = UUID.randomUUID().toString(),
            contact = call.contact,
            callType = call.callType,
            timestamp = System.currentTimeMillis(),
            durationFormatted = durationFormatted.ifEmpty { "00:00" },
            wasIncoming = (call.direction == CallDirection.INCOMING),
            wasMissed = (call.durationSeconds == 0)
        )
        _callLogs.update { listOf(log) + it }

        scope.launch {
            delay(400)
            _activeCall.value = null
        }
    }

    fun zeroizeAllData() {
        _messages.value = emptyMap()
        _callLogs.value = emptyList()
        _identity.update {
            it.copy(
                username = "Aayush Cipher",
                tag = CryptoEngine.generateUniqueTag("aayush"),
                fingerprint = CryptoEngine.generateFingerprint()
            )
        }
        lockApp()
    }
}
