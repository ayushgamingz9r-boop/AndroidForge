package com.example.data

import android.content.Context
import android.util.Log
import com.example.model.DeliveryStatus
import com.example.model.MediaType
import com.example.model.Message
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class FirestoreSyncManager(
    private val context: Context,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {
    private val TAG = "FirestoreSyncManager"

    private val firestore: FirebaseFirestore? by lazy {
        try {
            val app = FirebaseApp.initializeApp(context) ?: FirebaseApp.getInstance()
            val dbId = try {
                val resId = context.resources.getIdentifier("firestore_database_id", "string", context.packageName)
                if (resId != 0) context.getString(resId) else null
            } catch (e: Exception) {
                null
            }

            if (!dbId.isNullOrBlank()) {
                FirebaseFirestore.getInstance(app, dbId)
            } else {
                FirebaseFirestore.getInstance(app)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing Firestore", e)
            null
        }
    }

    private val activeListeners = mutableMapOf<String, ListenerRegistration>()

    fun startListeningToChannel(
        channelId: String,
        currentUserId: String,
        onNewMessageReceived: (Message) -> Unit
    ) {
        val db = firestore ?: return
        if (activeListeners.containsKey(channelId)) return

        try {
            val registration = db.collection("channels")
                .document(channelId)
                .collection("messages")
                .orderBy("timestamp", Query.Direction.ASCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.e(TAG, "Listen error for channel $channelId", error)
                        return@addSnapshotListener
                    }

                    if (snapshot != null) {
                        for (change in snapshot.documentChanges) {
                            if (change.type == com.google.firebase.firestore.DocumentChange.Type.ADDED) {
                                val doc = change.document
                                val senderId = doc.getString("senderId") ?: ""
                                if (senderId != currentUserId) {
                                    val mediaTypeName = doc.getString("mediaType") ?: MediaType.NONE.name
                                    val mediaType = try {
                                        MediaType.valueOf(mediaTypeName)
                                    } catch (e: Exception) {
                                        MediaType.NONE
                                    }

                                    val msg = Message(
                                        id = doc.getString("id") ?: doc.id,
                                        chatId = channelId,
                                        senderId = senderId,
                                        senderName = doc.getString("senderName") ?: "Online Peer",
                                        text = doc.getString("text") ?: "",
                                        cipherText = doc.getString("cipherText") ?: "",
                                        timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis(),
                                        timeFormatted = doc.getString("timeFormatted") ?: "",
                                        isFromMe = false,
                                        mediaType = mediaType,
                                        mediaUri = doc.getString("mediaUri"),
                                        audioDurationSeconds = doc.getLong("audioDurationSeconds")?.toInt() ?: 0,
                                        videoDurationSeconds = doc.getLong("videoDurationSeconds")?.toInt() ?: 0,
                                        savedInGallery = false,
                                        deliveryStatus = DeliveryStatus.READ
                                    )
                                    onNewMessageReceived(msg)
                                }
                            }
                        }
                    }
                }
            activeListeners[channelId] = registration
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start listening to channel $channelId", e)
        }
    }

    fun publishMessage(message: Message, enclavePasscode: String) {
        val db = firestore ?: return
        scope.launch {
            try {
                val data = hashMapOf(
                    "id" to message.id,
                    "chatId" to message.chatId,
                    "senderId" to message.senderId,
                    "senderName" to message.senderName,
                    "text" to message.text,
                    "cipherText" to message.cipherText,
                    "timestamp" to message.timestamp,
                    "timeFormatted" to message.timeFormatted,
                    "mediaType" to message.mediaType.name,
                    "mediaUri" to (message.mediaUri ?: ""),
                    "audioDurationSeconds" to message.audioDurationSeconds,
                    "videoDurationSeconds" to message.videoDurationSeconds,
                    "savedInGallery" to false,
                    "enclavePasscode" to enclavePasscode
                )

                db.collection("channels")
                    .document(message.chatId)
                    .collection("messages")
                    .document(message.id)
                    .set(data)
                    .addOnSuccessListener {
                        Log.d(TAG, "Message published successfully: ${message.id}")
                    }
                    .addOnFailureListener { e ->
                        Log.e(TAG, "Failed to publish message", e)
                    }
            } catch (e: Exception) {
                Log.e(TAG, "Exception publishing message", e)
            }
        }
    }

    fun stopListening(channelId: String) {
        activeListeners[channelId]?.remove()
        activeListeners.remove(channelId)
    }

    fun stopAll() {
        activeListeners.values.forEach { it.remove() }
        activeListeners.clear()
    }
}
