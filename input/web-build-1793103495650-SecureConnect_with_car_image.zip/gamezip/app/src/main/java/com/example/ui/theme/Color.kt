package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// CyberShield High-Security Dark Palette
val CyberBackground = Color(0xFF090D14)
val CyberSurface = Color(0xFF101722)
val CyberSurfaceVariant = Color(0xFF172233)
val CyberSurfaceElevated = Color(0xFF1F2E45)

val CyberPrimary = Color(0xFF00E599) // Neon Emerald Cipher
val CyberPrimaryContainer = Color(0xFF003822)
val CyberOnPrimary = Color(0xFF002113)
val CyberOnPrimaryContainer = Color(0xFF67FFBA)

val CyberSecondary = Color(0xFF00E5FF) // Cyber Cyan
val CyberSecondaryContainer = Color(0xFF00363D)
val CyberOnSecondary = Color(0xFF002024)

val CyberTertiary = Color(0xFF8B5CF6) // Cryptographic Purple
val CyberTertiaryContainer = Color(0xFF2E1065)

val CyberError = Color(0xFFFF4D4F) // Alert / End call
val CyberOnError = Color(0xFFFFFFFF)

val CyberOnBackground = Color(0xFFEDF2F7)
val CyberOnSurface = Color(0xFFE2E8F0)
val CyberOnSurfaceVariant = Color(0xFF94A3B8)
val CyberOutline = Color(0xFF26354A)
val CyberOutlineVariant = Color(0xFF1B283B)
