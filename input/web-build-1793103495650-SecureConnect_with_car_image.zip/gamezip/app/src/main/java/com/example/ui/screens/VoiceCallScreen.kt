package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CallStatus
import com.example.ui.CipherViewModel
import com.example.ui.components.AvatarBadge
import com.example.ui.components.EncryptedBadge
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberError
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberSecondary
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.util.CryptoEngine

@Composable
fun VoiceCallScreen(viewModel: CipherViewModel) {
    val callState = viewModel.activeCall.collectAsState().value ?: return
    val contact = callState.contact

    BackHandler {
        viewModel.endCall()
    }

    val transition = rememberInfiniteTransition(label = "audioRadar")
    val waveScale by transition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "radarScale"
    )
    val waveAlpha by transition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "radarAlpha"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        CyberBackground,
                        CyberSurface,
                        CyberBackground
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Info
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                EncryptedBadge(text = "E2EE VOICE • 256-BIT SRTP")

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = contact.name,
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = contact.tag,
                    color = CyberPrimary,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(top = 2.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                val statusDisplay = when (callState.status) {
                    CallStatus.DIALING -> "Dialing Secure Node..."
                    CallStatus.RINGING -> "Ringing Encrypted Receiver..."
                    CallStatus.CONNECTING_HANDSHAKE -> "Negotiating Ephemeral Keys..."
                    CallStatus.ACTIVE_ENCRYPTED -> CryptoEngine.formatDuration(callState.durationSeconds)
                    CallStatus.ENDED -> "Call Ended"
                }

                Text(
                    text = statusDisplay,
                    color = if (callState.status == CallStatus.ACTIVE_ENCRYPTED) CyberSecondary else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Central Animated Pulsing Radar & Avatar
            Box(
                modifier = Modifier.size(240.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    if (callState.status == CallStatus.ACTIVE_ENCRYPTED) {
                        drawCircle(
                            color = CyberPrimary.copy(alpha = waveAlpha),
                            radius = (size.minDimension / 2.2f) * waveScale,
                            style = Stroke(width = 2.dp.toPx())
                        )
                        drawCircle(
                            color = CyberSecondary.copy(alpha = waveAlpha * 0.7f),
                            radius = (size.minDimension / 2.6f) * (waveScale * 0.9f),
                            style = Stroke(width = 1.5.dp.toPx())
                        )
                    }
                }

                AvatarBadge(
                    avatarId = contact.avatarId,
                    size = 110.dp,
                    showOnlineStatus = false
                )
            }

            // Safety Numbers & Audio Telemetry
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = CyberSurfaceElevated.copy(alpha = 0.8f),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberOutline)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = CyberPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "SAFETY KEY: ${contact.fingerprint.take(19)}",
                            fontSize = 11.sp,
                            color = CyberPrimary,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Encrypted direct stream • Zero carrier relay • Opus 48kHz HD",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Call Action Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Mute Mic
                CallControlButton(
                    icon = if (callState.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                    isActive = callState.isMuted,
                    activeColor = CyberError,
                    inactiveColor = CyberSurfaceElevated,
                    label = if (callState.isMuted) "Unmute" else "Mute",
                    onClick = { viewModel.toggleMute() }
                )

                // Speakerphone
                CallControlButton(
                    icon = if (callState.isSpeakerOn) Icons.Default.VolumeUp else Icons.Default.VolumeDown,
                    isActive = callState.isSpeakerOn,
                    activeColor = CyberSecondary,
                    inactiveColor = CyberSurfaceElevated,
                    label = if (callState.isSpeakerOn) "Speaker" else "Earpiece",
                    onClick = { viewModel.toggleSpeaker() }
                )

                // Switch to Video
                CallControlButton(
                    icon = Icons.Default.Videocam,
                    isActive = false,
                    activeColor = CyberPrimary,
                    inactiveColor = CyberSurfaceElevated,
                    label = "Video",
                    onClick = { viewModel.startVideoCall(contact) }
                )

                // End Call
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(CyberError)
                        .clickable { viewModel.endCall() }
                        .testTag("end_voice_call_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CallEnd,
                        contentDescription = "End Call",
                        tint = Color.White,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun CallControlButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isActive: Boolean,
    activeColor: Color,
    inactiveColor: Color,
    label: String,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(if (isActive) activeColor else inactiveColor)
                .border(1.dp, CyberOutline, CircleShape)
                .clickable { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isActive) CyberBackground else Color.White,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
