NITRO RUSH 3D - Android project

Yeh Android Studio project hai, direct APK nahi.

APK banane ke steps:
1. Computer par Android Studio install/open karein.
2. Is ZIP ko extract karein.
3. Android Studio > Open > extracted NitroRush3D_Android folder select karein.
4. Gradle sync complete hone dein (internet zaroori ho sakta hai).
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK app/build/outputs/apk/debug/app-debug.apk par milega.

Important:
- Game landscape/fullscreen mode mein chalega.
- HTML game Three.js ko cdnjs.cloudflare.com se load karta hai, isliye pehli baar aur game chalate waqt internet connection chahiye.
- APK ko Android Studio/Android SDK ke saath build karna hoga. Is environment mein Android SDK/Gradle available nahi tha, isliye yahan final APK compile nahi ho saka.
