NITRO RUSH 3D - Android Studio project (Ayush Gaming Studio)

HOW TO MAKE THE APK
1. Install Android Studio (free) on a computer.
2. File > Open > choose this NitroRush folder. Wait for "Gradle sync" to finish (needs internet the first time).
3. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s).
4. When it says "APK(s) generated", click "locate". The file is app/build/outputs/apk/debug/app-debug.apk
5. Copy the APK to your phone and install it (allow "install unknown apps" if asked).

NOTES
- The game page is app/src/main/assets/index.html (landscape locked, fullscreen).
- The game loads the three.js library from the internet (cdnjs), so the phone needs internet when it starts.
  For fully offline use: download https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js,
  put it in app/src/main/assets/ and change the <script src="..."> line in index.html to src="three.min.js".
- For a Play Store release you need a signed release build (Build > Generate Signed Bundle / APK), your own icon and your own cars/textures (the ones used for testing may not be free to publish).
